const Text =() =>{
    return(
        <div>text</div>
    )
}
export default Text;