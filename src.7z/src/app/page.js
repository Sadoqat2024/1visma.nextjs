import Home from "./component/home"


const HomePage = () =>{
  return(
    <Home/>
  )
}

export default HomePage

