import './search.css'


const SearchInput = ()=> {
    return(
       
        <input type ="search" className ="search-cont" placeholder="What?"/>
    )
}
export default SearchInput