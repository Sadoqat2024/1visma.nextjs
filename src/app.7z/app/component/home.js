'use client';
import styles from './home.module.css'

const Home = () =>{
    return(
        <div className={styles.home_container}>
            <img className={styles.photo_container} alt="pic"  src="https://s3-alpha-sig.figma.com/img/c57d/560c/19a1563b86789d52771e3672bd069cbe?Expires=1724025600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=VxLris2eTDISwsr1oXO7VGAvyHr6aB-XC-e-9OlJKi747IF4aIajPM-GNZkAgtpyJ5f-xuYhCkkds3ixYngy97nRg27m8GbBV9~wq~MMkAZ82NZS1RVNYY2o7cqIX5rzMTfns1UP8QOA69j1fKKhM6zdYAsYwN7lx1Im~kVq~4SodoAMJMBEZayK8sXmTDvmk8SgocuuRxEZWID-sHxWZnGLBvUQnit800HuKIjDbaSoaKVYSV3zzpMu~GgDtX51XUVXJOrhzfuGeGCYjjFoDHczvNHy6qzKPXpWxjTazWo2Krfu8R8GLsbWiNV0rVtdIdHn2tKRevyEzlp0XoHxHQ__"/>
            <h1>loremcverukwgfbvyerbv</h1>
            <p>gbwecvtweyvcbyuebycvy</p>
        </div>
        
    )
}

export default Home;